LAUNDRIX PUBLIC WEBSITE
Upload index.html to the ROOT of your GitHub Laundrix repository.
This is a public marketing preview only. It does not contain the management app or real login.
Connect GitHub repository to Vercel and deploy as a static site.
Do not upload the local demo app or real customer data to a public repository.
